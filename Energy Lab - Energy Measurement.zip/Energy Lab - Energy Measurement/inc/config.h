#ifndef CONFIG_H
#define CONFIG_H

#define USE_SLEEP_MODES (1)

#endif
