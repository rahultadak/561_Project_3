#ifndef GPIO_DEFS_H
#define GPIO_DEFS_H

#define MASK(x) (1UL << (x))

// Debug output
#define DEBUG_RUNNING_POS 30 // on Port E - pin 11 of J10

#endif
// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
